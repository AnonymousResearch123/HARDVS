

CUDA_VISIBLE_DEVICES=0 python tools/train.py configs/recognition/hardvs_ESTF/hardvs_ESTF.py --work-dir work_dirs/hardvs_ESTF --validate --seed 0 --deterministic --gpu-ids=0


